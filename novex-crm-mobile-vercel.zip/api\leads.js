const { randomUUID } = require("node:crypto");

const MAX_LEADS = 500;

function json(res, status, response) {
  res.statusCode = status;
  res.setHeader("content-type", "application/json; charset=utf-8");
  res.setHeader("access-control-allow-origin", "*");
  res.setHeader("access-control-allow-methods", "GET,POST,OPTIONS");
  res.setHeader("access-control-allow-headers", "content-type,x-novex-token");
  res.end(JSON.stringify(response));
}

function requiredEnv() {
  return process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN;
}

async function redis(command) {
  const url = `${process.env.UPSTASH_REDIS_REST_URL}/pipeline`;
  const response = await fetch(url, {
    method: "POST",
    headers: {
      authorization: `Bearer ${process.env.UPSTASH_REDIS_REST_TOKEN}`,
      "content-type": "application/json"
    },
    body: JSON.stringify([command])
  });
  if (!response.ok) throw new Error(`Redis request failed: ${response.status}`);
  const [result] = await response.json();
  if (result.error) throw new Error(result.error);
  return result.result;
}

function normalizeLead(input) {
  const now = new Date().toISOString();
  return {
    id: String(input.id || randomUUID()),
    name: String(input.name || input.full_name || input.customer || "Unnamed lead"),
    phone: String(input.phone || input.mobile || input.tel || ""),
    source: String(input.source || input.channel || "Webhook"),
    value: Number(input.value || input.amount || 0),
    notes: String(input.notes || input.note || input.message || ""),
    status: String(input.status || "new").toLowerCase(),
    priority: String(input.priority || "normal").toLowerCase(),
    createdAt: input.createdAt || input.created_at || now,
    updatedAt: input.updatedAt || input.updated_at || now
  };
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    if (req.body) {
      resolve(typeof req.body === "string" ? JSON.parse(req.body) : req.body);
      return;
    }

    const chunks = [];
    req.on("data", (chunk) => chunks.push(chunk));
    req.on("end", () => {
      const raw = Buffer.concat(chunks).toString("utf8");
      resolve(raw ? JSON.parse(raw) : {});
    });
    req.on("error", reject);
  });
}

module.exports = async function handler(req, res) {
  if (req.method === "OPTIONS") return json(res, 200, { ok: true });

  if (!requiredEnv()) {
    return json(res, 503, {
      error: "Lead storage is not configured.",
      setup: "Add UPSTASH_REDIS_REST_URL and UPSTASH_REDIS_REST_TOKEN to Vercel environment variables."
    });
  }

  try {
    if (req.method === "POST") {
      const expectedToken = process.env.NOVEX_WEBHOOK_TOKEN;
      if (expectedToken && req.headers["x-novex-token"] !== expectedToken) {
        return json(res, 401, { error: "Unauthorized webhook token." });
      }

      const body = await readBody(req);
      const entries = Array.isArray(body) ? body : Array.isArray(body.leads) ? body.leads : [body];
      const leads = entries.map(normalizeLead);
      const serialized = leads.map((lead) => JSON.stringify(lead));
      await redis(["LPUSH", "novex:leads", ...serialized]);
      await redis(["LTRIM", "novex:leads", 0, MAX_LEADS - 1]);
      return json(res, 200, { ok: true, received: leads.length, leads });
    }

    if (req.method === "GET") {
      const since = new URL(req.url, "https://novex.local").searchParams.get("since");
      const rows = await redis(["LRANGE", "novex:leads", 0, MAX_LEADS - 1]);
      const leads = rows.map((row) => JSON.parse(row));
      const filtered = since ? leads.filter((lead) => new Date(lead.updatedAt) > new Date(since)) : leads;
      return json(res, 200, { leads: filtered });
    }

    return json(res, 405, { error: "Method not allowed." });
  } catch (error) {
    return json(res, 500, { error: error.message || "Unexpected lead API error." });
  }
};
