const STORAGE_KEY = "novex-leads";
const LAST_SYNC_KEY = "novex-last-sync";

const state = {
  leads: [],
  filter: "all",
  search: "",
  deferredInstall: null
};

const leadList = document.querySelector("#leadList");
const syncStatus = document.querySelector("#syncStatus");
const statusDot = document.querySelector("#statusDot");
const syncButton = document.querySelector("#syncButton");
const searchInput = document.querySelector("#searchInput");
const installButton = document.querySelector("#installButton");
const leadDialog = document.querySelector("#leadDialog");
const leadForm = document.querySelector("#leadForm");

function readLeads() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  } catch {
    return [];
  }
}

function saveLeads() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state.leads));
}

function normalizeLead(input) {
  const now = new Date().toISOString();
  return {
    id: input.id || crypto.randomUUID(),
    name: input.name || "Unnamed lead",
    phone: input.phone || "",
    source: input.source || "Manual",
    value: Number(input.value || 0),
    notes: input.notes || input.note || "",
    status: input.status || "new",
    priority: input.priority || "normal",
    updatedAt: input.updatedAt || now,
    createdAt: input.createdAt || now
  };
}

function mergeLeads(incoming) {
  const byId = new Map(state.leads.map((lead) => [lead.id, lead]));
  incoming.map(normalizeLead).forEach((lead) => {
    const previous = byId.get(lead.id);
    byId.set(lead.id, { ...previous, ...lead });
  });
  state.leads = Array.from(byId.values()).sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
  saveLeads();
  render();
}

function money(value) {
  if (!value) return "";
  return new Intl.NumberFormat(undefined, {
    style: "currency",
    currency: "ZAR",
    maximumFractionDigits: 0
  }).format(value);
}

function relativeTime(value) {
  const diff = Date.now() - new Date(value).getTime();
  const minutes = Math.max(1, Math.round(diff / 60000));
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.round(hours / 24)}d ago`;
}

function renderMetrics() {
  const today = new Date().toDateString();
  document.querySelector("#newCount").textContent = state.leads.filter((lead) => lead.status === "new").length;
  document.querySelector("#hotCount").textContent = state.leads.filter((lead) => lead.priority === "hot").length;
  document.querySelector("#todayCount").textContent = state.leads.filter((lead) => new Date(lead.updatedAt).toDateString() === today).length;
}

function filteredLeads() {
  const term = state.search.trim().toLowerCase();
  return state.leads.filter((lead) => {
    const statusMatch = state.filter === "all" || lead.status === state.filter;
    const searchMatch = !term || [lead.name, lead.phone, lead.source, lead.notes].join(" ").toLowerCase().includes(term);
    return statusMatch && searchMatch;
  });
}

function render() {
  renderMetrics();
  const leads = filteredLeads();
  if (!leads.length) {
    leadList.innerHTML = `<div class="empty">No leads in this view yet.</div>`;
    return;
  }

  leadList.innerHTML = leads.map((lead) => `
    <article class="lead-card" data-id="${lead.id}">
      <header>
        <div>
          <h3>${escapeHtml(lead.name)}</h3>
          <p class="meta">${escapeHtml(lead.source)} ${lead.phone ? `- ${escapeHtml(lead.phone)}` : ""} ${lead.value ? `- ${money(lead.value)}` : ""}</p>
        </div>
        <span class="badge ${lead.priority === "hot" ? "hot" : ""}">${escapeHtml(lead.status)}</span>
      </header>
      ${lead.notes ? `<p class="note">${escapeHtml(lead.notes)}</p>` : ""}
      <p class="time">${relativeTime(lead.updatedAt)}</p>
      <div class="lead-actions">
        <button type="button" data-action="new">New</button>
        <button type="button" data-action="contacted">Contacted</button>
        <button type="button" data-action="won">Won</button>
      </div>
    </article>
  `).join("");
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[char]));
}

async function syncLeads() {
  statusDot.className = "status-dot warn";
  syncStatus.textContent = "Checking lead updates...";
  try {
    const since = localStorage.getItem(LAST_SYNC_KEY) || "";
    const response = await fetch(`/api/leads${since ? `?since=${encodeURIComponent(since)}` : ""}`, {
      headers: { "Accept": "application/json" }
    });
    if (!response.ok) throw new Error(`Sync failed with ${response.status}`);
    const data = await response.json();
    const received = Array.isArray(data.leads) ? data.leads : data;
    mergeLeads(received);
    localStorage.setItem(LAST_SYNC_KEY, new Date().toISOString());
    statusDot.className = "status-dot";
    syncStatus.textContent = received.length === 1 ? "1 lead update received" : `${received.length} lead updates received`;
  } catch (error) {
    statusDot.className = "status-dot error";
    syncStatus.textContent = "Offline or webhook store not configured";
  }
}

function seedDemoLead() {
  if (state.leads.length) return;
  mergeLeads([
    {
      id: "demo-1",
      name: "Amina Patel",
      phone: "+27 82 555 0148",
      source: "Website",
      value: 34000,
      notes: "Requested a quote and wants a call before 15:00.",
      priority: "hot",
      status: "new"
    }
  ]);
}

window.addEventListener("beforeinstallprompt", (event) => {
  event.preventDefault();
  state.deferredInstall = event;
  installButton.hidden = false;
});

installButton.addEventListener("click", async () => {
  if (!state.deferredInstall) return;
  state.deferredInstall.prompt();
  await state.deferredInstall.userChoice;
  state.deferredInstall = null;
});

syncButton.addEventListener("click", syncLeads);

searchInput.addEventListener("input", (event) => {
  state.search = event.target.value;
  render();
});

document.querySelectorAll(".segment").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".segment").forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    state.filter = button.dataset.filter;
    render();
  });
});

document.querySelector("#newLeadButton").addEventListener("click", () => leadDialog.showModal());

leadForm.addEventListener("submit", (event) => {
  if (event.submitter?.value === "cancel") return;
  event.preventDefault();
  const formData = new FormData(leadForm);
  mergeLeads([Object.fromEntries(formData.entries())]);
  leadForm.reset();
  leadDialog.close();
});

leadList.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const card = event.target.closest(".lead-card");
  state.leads = state.leads.map((lead) => {
    if (lead.id !== card.dataset.id) return lead;
    return { ...lead, status: button.dataset.action, updatedAt: new Date().toISOString() };
  });
  saveLeads();
  render();
});

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("/sw.js");
}

state.leads = readLeads();
seedDemoLead();
render();
setInterval(syncLeads, 60000);
